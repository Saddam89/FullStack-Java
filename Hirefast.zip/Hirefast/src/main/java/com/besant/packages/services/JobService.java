package com.besant.packages.services;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface JobService {

	public void postJob(HttpServletRequest req, HttpServletResponse resp);
	public void applyForJob(HttpServletRequest req, HttpServletResponse resp);
}
