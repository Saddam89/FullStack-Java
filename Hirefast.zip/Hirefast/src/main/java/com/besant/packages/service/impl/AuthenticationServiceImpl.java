package com.besant.packages.service.impl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.besant.packages.services.AuthenticationService;
import com.mysql.cj.protocol.Resultset;

public class AuthenticationServiceImpl implements AuthenticationService {

	@Override
	public void orgSignup(HttpServletRequest req, HttpServletResponse resp) {
		try {
			// Step 1: Load the MySQL driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Step 2: Create connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hirefast", "root", "root");

			// Step 3: Prepare statement
			PreparedStatement statement = connection
					.prepareStatement("insert into org_auth (email,password, type) values (?,?,'org')");
			statement.setString(1, req.getParameter("email"));
			statement.setString(2, req.getParameter("password"));
			// Step 4: Execute
			int rows = statement.executeUpdate();
			if (rows >= 1) {
				resp.sendRedirect("/Hirefast/OrgLogin.html");
			} else {
				resp.sendRedirect("/Hirefast/404.html");
			}
			// Step 5: Close
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void orgLogin(HttpServletRequest req, HttpServletResponse resp) {
		try {
			// Step 1: Load the MySQL driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Step 2: Create connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hirefast", "root", "root");

			// Step 3: Prepare statement
			PreparedStatement statement = connection
					.prepareStatement("select * from org_auth  where email = ? and password = ?;");
			statement.setString(1, req.getParameter("email"));
			statement.setString(2, req.getParameter("password"));
			// Step 4: Execute
			ResultSet set = statement.executeQuery();

			while (set.next()) {
				HttpSession session = req.getSession();
				session.setAttribute("orgId", set.getString("orgId"));
				resp.sendRedirect("/Hirefast/OrgDashboard.html");
			}

			// Step 5: Close
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void userSignup(HttpServletRequest req, HttpServletResponse resp) {
		try {
			// Step 1: Load the MySQL driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Step 2: Create connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hirefast", "root", "root");

			// Step 3: Prepare statement
			PreparedStatement statement = connection
					.prepareStatement("insert into user_auth (email,password, type) values (?,?,'ind')");
			statement.setString(1, req.getParameter("email"));
			statement.setString(2, req.getParameter("password"));
			// Step 4: Execute
			int rows = statement.executeUpdate();
			if (rows >= 1) {
				resp.sendRedirect("/Hirefast/UserLogin.html");
			} else {
				resp.sendRedirect("/Hirefast/404.html");
			}
			// Step 5: Close
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void userLogin(HttpServletRequest req, HttpServletResponse resp) {
		try {
			// Step 1: Load the MySQL driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Step 2: Create connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hirefast", "root", "root");

			// Step 3: Prepare statement
			PreparedStatement statement = connection
					.prepareStatement("select * from user_auth  where email = ? and password = ?;");
			statement.setString(1, req.getParameter("email"));
			statement.setString(2, req.getParameter("password"));
			// Step 4: Execute
			ResultSet set = statement.executeQuery();

			while (set.next()) {
				
				HttpSession session = req.getSession();
				session.setAttribute("userId", set.getString("userId"));
				resp.sendRedirect("/Hirefast/UserDashboard.html");
			}

			// Step 5: Close
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
