package com.besant.packages.service.impl;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.HttpSession;

import com.besant.packages.services.JobService;

public class JobServiceImpl implements JobService {

	@Override
	public void postJob(HttpServletRequest req, HttpServletResponse resp) {
		try {
			// Step 1: Load the MySQL driver
			Class.forName("com.mysql.cj.jdbc.Driver");

			// Step 2: Create connection
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/hirefast", "root", "root");

			// Step 3: Prepare statement
			PreparedStatement statement = connection.prepareStatement(
					"insert into all_jobs(title,job_description,role,salary,vacany,orgName,orgId) values (?,?,?,?,?,?,?)");
			statement.setString(1, req.getParameter("title"));
			statement.setString(2, req.getParameter("jd"));
			statement.setString(3, req.getParameter("role"));
			statement.setInt(4, Integer.parseInt(req.getParameter("salary")));
			statement.setInt(5, Integer.parseInt(req.getParameter("vacancy")));
			statement.setString(6, req.getParameter("orgName"));

			HttpSession session = req.getSession();

			System.out.println(session.getAttribute("orgId"));
			statement.setInt(7, Integer.parseInt((String) session.getAttribute("orgId")));
			// Step 4: Execute
			int rows = statement.executeUpdate();
			if (rows >= 1) {
				resp.sendRedirect("/Hirefast/OrgDashboard.html");
			} else {
				resp.sendRedirect("/Hirefast/404.html");
			}
			// Step 5: Close
			connection.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public void applyForJob(HttpServletRequest req, HttpServletResponse resp) {
		// Get form data
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String phone = req.getParameter("phone");
		String location = req.getParameter("location");
		String education = req.getParameter("education");
		String message = req.getParameter("message");
		int experience = Integer.parseInt(req.getParameter("experience"));
		int jobId = Integer.parseInt(req.getParameter("jobId"));

		try {
			// Connect to DB
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hirefast", "root", "root");

			// Optional: Get userId from session
			HttpSession session = req.getSession();
			int userId = Integer.parseInt((String) session.getAttribute("userId")); // make sure session has this set during login

			// Insert application
			String sql = "INSERT INTO applications (name, email, phone, location, education, message, experience, userId, jobId, createdAt) "
					+ "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, now())";

			PreparedStatement stmt = conn.prepareStatement(sql);
			stmt.setString(1, name);
			stmt.setString(2, email);
			stmt.setString(3, phone);
			stmt.setString(4, location);
			stmt.setString(5, education);
			stmt.setString(6, message);
			stmt.setInt(7, experience);
			stmt.setInt(8, userId);
			stmt.setInt(9, jobId);

			int rows = stmt.executeUpdate();

			if (rows > 0) {
				// Redirect to My Applications page
				resp.sendRedirect("/Hirefast/UserApplication.jsp");
			} else {
				resp.getWriter().println("Application failed.");
			}

			conn.close();

		} catch (Exception e) {
			e.printStackTrace();
			try {
				resp.getWriter().println("Error: " + e.getMessage());
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

}
